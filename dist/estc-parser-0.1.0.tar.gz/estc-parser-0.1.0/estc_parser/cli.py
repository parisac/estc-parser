from .parser import files2csv
from utils.config import INPUT_PATH


if __name__ == "__main__":
    files2csv(INPUT_PATH)
