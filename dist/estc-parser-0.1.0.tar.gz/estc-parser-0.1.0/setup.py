# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['estc_parser', 'estc_parser.utils']

package_data = \
{'': ['*']}

install_requires = \
['beautifulsoup4>=4.8.2,<5.0.0', 'pandas==1.0.1']

entry_points = \
{'console_scripts': ['chew = etsc_parser.cli:main']}

setup_kwargs = {
    'name': 'estc-parser',
    'version': '0.1.0',
    'description': 'package to parse html downloaded from the english short title catalogue',
    'long_description': None,
    'author': 'parisac',
    'author_email': 'alex.charles.paris@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
